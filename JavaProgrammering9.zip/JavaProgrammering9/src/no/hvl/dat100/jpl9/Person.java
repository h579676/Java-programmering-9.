package no.hvl.dat100.jpl9;

public abstract class Person {
	private String etternamn;
	private String fornamn;
	private long fodselsnummer;

	public Person() {
	}

	public Person(String etternamn, String fornamn, long fodselsnummer) {
		this.etternamn = etternamn;
		this.fornamn = fornamn;
		this.fodselsnummer = fodselsnummer;
	}

	public String getEtternamn() {
		return etternamn;
	}

	public void setEtternamn(String etternamn) {
		this.etternamn = etternamn;
	}

	public String getFornamn() {
		return fornamn;
	}

	public void setFornamn(String fornamn) {
		this.fornamn = fornamn;
	}

	public void setFodselsnummer(long fodselsnummer) {
		this.fodselsnummer = fodselsnummer;
	}

	public long getFodselsnummer() {
		return fodselsnummer;
	}
	
	public boolean erLik(Person person) {
		return this.fodselsnummer==person.fodselsnummer;
		
	}
	

	public boolean erKvinne() {
		int i = Integer.parseInt(Long.toString(fodselsnummer).substring(8, 9));
		
		if (i%2 == 0) {
		    return true;
	}
		    return false;
}		    

	public boolean erMann() {
        int i = Integer.parseInt(Long.toString(fodselsnummer).substring(8, 9));
		
		if (i%2 == 1) {
		    return true;
		}
		    return false;
	}

	@Override
	public String toString() {
		return fodselsnummer + "\n" + etternamn + "\n" + fornamn + "\n";
	}
}

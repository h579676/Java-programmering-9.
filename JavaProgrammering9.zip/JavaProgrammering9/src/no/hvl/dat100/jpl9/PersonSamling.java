package no.hvl.dat100.jpl9;

public class PersonSamling {
	private Person[] tabell;

	private int nesteledig;

	public PersonSamling() {
		tabell = new Person[20];
		nesteledig = 0;

	}

	public PersonSamling(int lengde) {

		tabell = new Person[lengde];
		nesteledig = 0;
		

	}

	public int getAntall() {

		return nesteledig;
	}

	// DO NOT TOUCH - FOR TESTING PURPOSES ONLY
	public void setAntall(int antall) {
		nesteledig = antall;
	}

	public Person[] getSamling() {

		return tabell;
		
	}

	public int finnPerson(Person p) {
		
		boolean funnet = false;
		int pos = 0;
		while (pos<nesteledig && !funnet) {
			if (tabell[pos].getFodselsnummer() == p.getFodselsnummer())
				funnet = true;
			else
				pos++;
		}
			if (funnet)
				return pos;
			else return -1;
		}

	

	public boolean finnes(Person p) {
		
		
		boolean finnes = false;
		for(int i = 0; i < nesteledig; i++) {
			if(p.erLik(tabell[i])) {
				finnes = true;
			}
		}
		return finnes;
	}

	public boolean ledigPlass() {
		
		
		boolean ikkeLedigPlass = false;
		for(int i = 0; i < tabell.length; i++) {
			if((tabell[i]) == null) {
			
				ikkeLedigPlass = true;
			}
		}
			return ikkeLedigPlass; }
	
	public boolean leggTil(Person p) {

		boolean ny = leggTil(p.getFodselsnummer()) == -1;
		if( ny && nesteledig < tabell.length) {
			tabell[nesteledig] = p;
			nesteledig++;
			return true;
		}	
		else
			return false;
	}

	private int leggTil(long fodselsnummer) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String toString() {

		return "STUDENT" + "\n" + super.toString() + "\n" + "LAERER" + "\n" + super.toString() + "\n";
	}

	public void utvid() {

		// TODO
		throw new RuntimeException("utvid not implemented");
	}

	public boolean leggTilUtvid(Person p) {

		// TODO
		throw new RuntimeException("leggTilUtvid not implemented");
	}

	public void slett(Person p) {

		// TODO
		throw new RuntimeException("slett not implemented");
	}
}
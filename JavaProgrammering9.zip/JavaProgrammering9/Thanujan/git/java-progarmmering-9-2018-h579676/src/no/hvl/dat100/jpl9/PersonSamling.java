Thanujan/git/java-progarmmering-9-2018-h579676/src/no/hvl/dat100/jpl9/PersonSamling.java
